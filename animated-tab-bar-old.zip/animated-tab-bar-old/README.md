# Animated Tab Bar (OLD)

A Pen created on CodePen.io. Original URL: [https://codepen.io/makamat/pen/pomGemy](https://codepen.io/makamat/pen/pomGemy).

Animated Tab Bar (OLD)