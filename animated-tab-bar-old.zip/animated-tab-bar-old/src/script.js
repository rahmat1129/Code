const dropdownBtn = document.getElementById("dropdownBtn");
const dropdownShapes = document.querySelectorAll(".tab-bar__dropdown-shape");

dropdownBtn.addEventListener("click", dropdownBtnClickHandler);

function dropdownBtnClickHandler(e) {
  if (e.currentTarget === dropdownBtn) dropdownAnimation();
}

function dropdownAnimation() {
  toggleClass(dropdownBtn, "active");
  dropdownShapes.forEach((dropShape) => toggleClass(dropShape, "active"));
}

function toggleClass(el, className) {
  el.classList.toggle(className);

  return el;
}
