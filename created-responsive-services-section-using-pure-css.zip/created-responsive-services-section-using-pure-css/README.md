# Created Responsive Services Section Using Pure CSS .

A Pen created on CodePen.io. Original URL: [https://codepen.io/Alhefel/pen/poxQwRZ](https://codepen.io/Alhefel/pen/poxQwRZ).

Created Responsive Services Section Using Pure CSS .