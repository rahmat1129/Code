const home = document.querySelector(".home")
const cart = document.querySelector(".cart")
const shop = document.querySelector(".shop")


const navBtn = document.querySelector(".nav-btn");

let navHandler = true;

navBtn.addEventListener("click", function(){
    if (navHandler){
    home.style.scale = "1"
    cart.style.scale = "1"
    shop.style.scale = "1"
    home.style.left = "0"
    home.style.bottom = "0"
    cart.style.bottom = "0"
    cart.style.right = "0"
    shop.style.bottom = "0"
    shop.style.right = "0"
    shop.style.transform = "rotate(360deg)"
    home.style.transform = "rotate(360deg)"
    cart.style.transform = "rotate(360deg)"
    navHandler = false;
}else{
    home.style.scale = "0"
    cart.style.scale = "0"
    shop.style.scale = "0"
    home.style.left = "20vw"
    home.style.bottom = "-25vh"
    cart.style.bottom = "-25vh"
    cart.style.right = "20vw"
    shop.style.bottom = "-25vh"
    shop.style.right = "3vw"
    shop.style.transform = "rotate(360deg)"
    home.style.transform = "rotate(360deg)"
    cart.style.transform = "rotate(360deg)"
    navHandler = true;
}
})