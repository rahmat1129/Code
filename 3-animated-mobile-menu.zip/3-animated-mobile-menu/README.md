# #3 | animated mobile menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/BobaStiicks/pen/LYowPNN](https://codepen.io/BobaStiicks/pen/LYowPNN).

simple and animated mobile menu using html css and js