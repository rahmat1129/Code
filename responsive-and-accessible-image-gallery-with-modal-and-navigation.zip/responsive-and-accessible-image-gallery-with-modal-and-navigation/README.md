# Responsive and Accessible Image Gallery with modal and navigation

A Pen created on CodePen.io. Original URL: [https://codepen.io/riccardo-andreatta/pen/BaEzJeG](https://codepen.io/riccardo-andreatta/pen/BaEzJeG).

