# Responsive Glassmorphic Services Section

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheMOZZARELLA/pen/vYmoQWB](https://codepen.io/TheMOZZARELLA/pen/vYmoQWB).

Fully responsive and animated glassmorphic services section.