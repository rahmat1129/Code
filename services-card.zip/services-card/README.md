# Services Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gogh/pen/poqaPOM](https://codepen.io/Gogh/pen/poqaPOM).

Creative Services Card Section with Skewed Outer Border Lines