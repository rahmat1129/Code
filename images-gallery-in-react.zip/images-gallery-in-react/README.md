# Images Gallery in React

A Pen created on CodePen.io. Original URL: [https://codepen.io/chriiss/pen/OJZPBML](https://codepen.io/chriiss/pen/OJZPBML).

