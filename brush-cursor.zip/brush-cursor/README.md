# Brush Cursor

A Pen created on CodePen.io. Original URL: [https://codepen.io/RitamChakraborty/pen/poZgOyP](https://codepen.io/RitamChakraborty/pen/poZgOyP).

Paint the text with the different movement of color. 