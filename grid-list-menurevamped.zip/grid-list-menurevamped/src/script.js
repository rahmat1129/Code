// Get the elements with class="column"
var elements = document.getElementsByClassName("pg_column");

// Declare a loop variable
var i;

// List View
function listView() {
  for (i = 0; i < elements.length; i++) {
    elements[i].style.width = "100%";
  }
}

// Grid View
function gridView() {
  for (i = 0; i < elements.length; i++) {
    elements[i].style.width = "33.33%";
  }
}

/*Active Buttons*/
var container = document.getElementById("pg_btn_container");
var pg_btn = container.getElementsByClassName("pg_btn");
for (var i = 0; i < pg_btn.length; i++) {
  pg_btn[i].addEventListener("click", function () {
    var current = document.getElementsByClassName("pg_btn_active");
    current[0].className = current[0].className.replace(" pg_btn_active", "");
    this.className += " pg_btn_active";
  });
}
