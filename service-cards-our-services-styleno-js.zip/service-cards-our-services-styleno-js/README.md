# Service Cards / Our Services Style - No JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gogh/pen/NWEXZZV](https://codepen.io/Gogh/pen/NWEXZZV).

Inverted Border Radius